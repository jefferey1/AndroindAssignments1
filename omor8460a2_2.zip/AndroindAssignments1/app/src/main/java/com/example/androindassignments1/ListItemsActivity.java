package com.example.androindassignments1;

import android.content.DialogInterface;
import android.content.Intent;
import android.provider.MediaStore;
import android.util.Log;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.content.SharedPreferences;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Button;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


@SuppressWarnings("deprecation")
public class ListItemsActivity extends AppCompatActivity {
    protected static final String ACTIVITY_NAME = "ListItemsActivity";
    protected static final int REQUEST_IMAGE_CAPTURE=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_items);
        //final String ACTIVITY_NAME = "ListItemsActivity";
        Log.i(ACTIVITY_NAME, "In onCreate()");
        ImageButton Imagebutton = findViewById(R.id.imageButton6);
        Imagebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if(takePictureIntent.resolveActivity(getPackageManager())!=null){
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                }
            }
        });

    }
    private void OnCheckedChanged(){
        AlertDialog.Builder builder = new AlertDialog.Builder(ListItemsActivity.this);
// 2. Chain together various setter methods to set the dialog characteristics
        builder.setMessage(R.string.dialog_message) //Add a dialog message to strings.xml

                .setTitle(R.string.dialog_title)
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User clicked OK button
                    }
                })
                .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User cancelled the dialog
                    }
                })
                .show();
    }
    protected void onResume() {
        super.onResume();
        final String ACTIVITY_NAME = "ListItemsActivity";
        Log.i(ACTIVITY_NAME, "In onResume()");
        //Log.i(ACTIVITY_NAME, "In onResume()");
    }

    protected void onStart() {
        super.onStart();
        final String ACTIVITY_NAME = "ListItemsActivity";
        Log.i(ACTIVITY_NAME, "In onStart()");
        //Log.i(ACTIVITY_NAME, "In onResume()");
    }

    protected void onPause() {
        super.onPause();
        final String ACTIVITY_NAME = "ListItemsActivity";
        Log.i(ACTIVITY_NAME, "In onPause()");
        //Log.i(ACTIVITY_NAME, "In onResume()");
    }

    protected void onStop() {
        super.onStop();
        final String ACTIVITY_NAME = "ListItemsActivity";
        Log.i(ACTIVITY_NAME, "In onStop()");
        //Log.i(ACTIVITY_NAME, "In onResume()");
    }

    protected void onDestroy() {
        super.onDestroy();
        final String ACTIVITY_NAME = "ListItemsActivity";
        Log.i(ACTIVITY_NAME, "In onDestroy()");
        //Log.i(ACTIVITY_NAME, "In onResume()");
    }

}