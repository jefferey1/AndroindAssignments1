package com.example.androindassignments1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
//import android.widget.Button;


public class LoginActivity extends AppCompatActivity {
    protected static final String EMAIL_KEY="someEmailkey";
    protected static final String PREFERENCE_KEY="somePreferenceKey";
    //public EditText email;
    //public Button LoginButton;
    SharedPreferences mPrefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final String ACTIVITY_NAME = "LoginActivity";
        Log.i(ACTIVITY_NAME, "In onCreate()");
        mPrefs = getSharedPreferences(PREFERENCE_KEY, Context.MODE_PRIVATE);
        String new_email_value = mPrefs.getString(EMAIL_KEY,"");
        ((EditText) findViewById(R.id.editTextTextPersonName)).setText(new_email_value);
        //Button LoginButton = findViewById(R.id.LoginButton);
        //SharedPreferences shared = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        //String a1= shared.getString("DefaultEmail", "email@domain.com");
        //email.setText(a1);
        //String new_email_entered = (String) ((EditText)) findViewById(R.id.LoginButton)).getText().toString();

    }

    private void saveEmailData(){
        SharedPreferences.Editor mEditor = mPrefs.edit();
        mEditor.clear();
        String new_email_entered = (String) ((EditText) findViewById(R.id.editTextTextPersonName)).getText().toString();
        mEditor.putString(EMAIL_KEY,new_email_entered);

        mEditor.commit();

    }

    public void onSavedClicked(View view){
        saveEmailData();
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
    }
    protected void onResume() {
        super.onResume();
        final String ACTIVITY_NAME = "LoginActivity";
        Log.i(ACTIVITY_NAME, "In onResume()");
        //Log.i(ACTIVITY_NAME, "In onResume()");
    }

    protected void onStart() {
        super.onStart();
        final String ACTIVITY_NAME = "LoginActivity";
        Log.i(ACTIVITY_NAME, "In onStart()");
        //Log.i(ACTIVITY_NAME, "In onResume()");
    }

    protected void onPause() {
        super.onPause();
        final String ACTIVITY_NAME = "LoginActivity";
        Log.i(ACTIVITY_NAME, "In onPause()");
        //Log.i(ACTIVITY_NAME, "In onResume()");
    }

    protected void onStop() {
        super.onStop();
        final String ACTIVITY_NAME = "LoginActivity";
        Log.i(ACTIVITY_NAME, "In onStop()");
        //Log.i(ACTIVITY_NAME, "In onResume()");
    }

    protected void onDestroy() {
        super.onDestroy();
        final String ACTIVITY_NAME = "LoginActivity";
        Log.i(ACTIVITY_NAME, "In onDestroy()");
        //Log.i(ACTIVITY_NAME, "In onResume()");
    }

}