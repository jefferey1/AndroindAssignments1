package com.example.androindassignments1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

@SuppressWarnings("deprecation")
public class MainActivity extends AppCompatActivity {
    protected static final String ACTIVITY_NAME="MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //final String ACTIVITY_NAME = "MainActivity";
        Log.i(ACTIVITY_NAME, "In onCreate()");
        findViewById(R.id.button);

    }

    public void onClick(View view){
        int LAUNCH_SECOND_ACTIVITY=10;
        Intent a = new Intent(this, ListItemsActivity.class);
        startActivityForResult(a, LAUNCH_SECOND_ACTIVITY);
        Intent resultIntent = new Intent(  );
        resultIntent.putExtra("Response", "Here is my response");
        setResult(Activity.RESULT_OK, resultIntent);
        finish();

    }

    public void onActivityResult(int requestCode, int responseCode, Intent data){


        super.onActivityResult(requestCode, responseCode, data);
        if(requestCode ==10){
            Log.i(ACTIVITY_NAME, "Returned to MainActivity.onActivityResult");
        }
    }
    protected void onResume() {
        super.onResume();
        final String ACTIVITY_NAME = "MainActivity";
        Log.i(ACTIVITY_NAME, "In onResume()");
        //Log.i(ACTIVITY_NAME, "In onResume()");
    }

    protected void onStart() {
        super.onStart();
        final String ACTIVITY_NAME = "MainActivity";
        Log.i(ACTIVITY_NAME, "In onStart()");
        //Log.i(ACTIVITY_NAME, "In onResume()");
    }

    protected void onPause() {
        super.onPause();
        final String ACTIVITY_NAME = "MainActivity";
        Log.i(ACTIVITY_NAME, "In onPause()");
        //Log.i(ACTIVITY_NAME, "In onResume()");
    }

    protected void onStop() {
        super.onStop();
        final String ACTIVITY_NAME = "MainActivity";
        Log.i(ACTIVITY_NAME, "In onCreate()");
        //Log.i(ACTIVITY_NAME, "In onResume()");
    }

    protected void onDestroy() {
        super.onDestroy();
        final String ACTIVITY_NAME = "MainActivity";
        Log.i(ACTIVITY_NAME, "In onDestroy()");
        //Log.i(ACTIVITY_NAME, "In onResume()");
    }




}